<footer>

<section class="footer-complet">
        <a href="index.php?action=accueil"><img src="assets/images/TCS.svg" alt="Logo de l'entreprise"></a>

        <section class="contact">
            <h4>CONTACT</h4>
            <p>contact@tcs-industrie.fr</p>
            <p>04.34.35.36.37</p>
        </section>    
        <div class="separateur-footer"></div>
        <section>
            <nav>
                <a href="index.php?action=accueil">Accueil</a>
                <a href="index.php?action=bureauEtude">Bureau d'étude</a>
                <a href="index.php?action=expertise">Notre expertise</a>
                <a href="index.php?action=recrutement">Recrutement</a>
                <a href="index.php?action=contact">Contact</a>
            </nav>
        </section>    
        <div class="separateur-footer"></div>  
        <section class="reseaux">
            <h4>SUIVEZ-NOUS</h4>
            <div>
                <img src="./assets/images/icone-linkedin.webp" alt="Logo de linkedin">
                <img src="./assets/images/icone-youtube.webp" alt="Logo de youtube">
                </div>
        </section>
</section>

<section class="mentions">
        <a href="index.php?action=mentionsLegales">Mentions Légales</a>
        <p>-</p>
        <p>Réalisation Code Création 2025</p>
</section>

<img class="btn-scroll" src="assets/images/fleche-vers-le-haut.webp" alt="flèche retour en haut de la page">



<!-- Scripts -->
<script src="/assets/js/btn-retour-haut.js" defer></script>

</footer>

</body>
</html>
